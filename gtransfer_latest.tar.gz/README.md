# New file distribution used #

As GitHub now supports a more useful form of file distribution
([GitHub releases]) the gtransfer tarballs are now available from the gtransfer
releases page:

https://github.com/fr4nk5ch31n3r/gtransfer/releases

****
> NOTICE: The [gtransfer downloads branch] will continue to be available for
> historic exploration.

[GitHub releases]: https://github.com/blog/1547-release-your-software
[gtransfer downloads branch]: https://github.com/fr4nk5ch31n3r/gtransfer/tree/downloads
